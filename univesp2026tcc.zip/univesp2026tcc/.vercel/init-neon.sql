-- Inicializacao das tabelas PTS no PostgreSQL. Preserva dados existentes.

BEGIN;

CREATE TABLE IF NOT EXISTS login_attempts (
	key VARCHAR(64) NOT NULL, 
	count INTEGER NOT NULL, 
	"window" BIGINT NOT NULL, 
	PRIMARY KEY (key)
);

CREATE TABLE IF NOT EXISTS permit_sequences (
	key VARCHAR(60) NOT NULL, 
	value INTEGER NOT NULL, 
	PRIMARY KEY (key)
);

CREATE TABLE IF NOT EXISTS permits (
	id VARCHAR(32) NOT NULL, 
	numero VARCHAR(80) NOT NULL, 
	categoria VARCHAR(20) NOT NULL, 
	status VARCHAR(20) NOT NULL, 
	local TEXT NOT NULL, 
	empresa TEXT NOT NULL, 
	created_at BIGINT NOT NULL, 
	updated_at BIGINT NOT NULL, 
	owner VARCHAR(100) NOT NULL, 
	request_id VARCHAR(200) NOT NULL, 
	request_hash VARCHAR(64) NOT NULL, 
	record TEXT NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (numero), 
	UNIQUE (request_id)
);

CREATE INDEX IF NOT EXISTS ix_permits_categoria ON permits (categoria);

CREATE INDEX IF NOT EXISTS ix_permits_created_at ON permits (created_at);

CREATE INDEX IF NOT EXISTS ix_permits_status ON permits (status);

CREATE TABLE IF NOT EXISTS schema_versions (
	version SERIAL NOT NULL, 
	PRIMARY KEY (version)
);

CREATE TABLE IF NOT EXISTS audit_events (
	id VARCHAR(32) NOT NULL, 
	permit_id VARCHAR(32) NOT NULL, 
	actor VARCHAR(100) NOT NULL, 
	action VARCHAR(50) NOT NULL, 
	at BIGINT NOT NULL, 
	details TEXT NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(permit_id) REFERENCES permits (id)
);

CREATE INDEX IF NOT EXISTS ix_audit_events_permit_id ON audit_events (permit_id);

CREATE TABLE IF NOT EXISTS evidence (
	id VARCHAR(64) NOT NULL, 
	permit_id VARCHAR(32) NOT NULL, 
	mime VARCHAR(30) NOT NULL, 
	content BYTEA NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(permit_id) REFERENCES permits (id)
);

CREATE INDEX IF NOT EXISTS ix_evidence_permit_id ON evidence (permit_id);

INSERT INTO schema_versions (version) SELECT 1 WHERE NOT EXISTS (SELECT 1 FROM schema_versions) ON CONFLICT DO NOTHING;

COMMIT;
